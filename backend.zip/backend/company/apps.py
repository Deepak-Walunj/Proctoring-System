from django.apps import AppConfig


class InterviewerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'company'
