def askbot(user_input):
    if(user_input=="start"):
        return "hello i am interviewer plz introduced yourself"
    else:
        return "good you are selected"