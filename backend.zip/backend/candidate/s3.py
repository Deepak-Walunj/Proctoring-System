import boto3
from botocore.exceptions import NoCredentialsError


# Initialize S3 client (for pre-signed URL generation)
s3_client = boto3.client(
    service_name='s3',
    region_name='ap-south-1',
    aws_access_key_id='AKIATAVAASXA5CGID7MF',
    aws_secret_access_key='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'
)

bucket_name = 'eduvantage-v1'
# file_path = "C:/Users/sachi/OneDrive/Pictures/newyear.mp4"
# file_key = 'newyear.mp4'

# Upload the file
def uploadToServer(file_obj,file_key):
    print("uploading video")
    s3_client.upload_file(
                    Filename=file_obj,
                    Bucket=bucket_name,
                    Key=file_key,
                    ExtraArgs={'ContentType': 'video/mp4'})

    print(f"\nFile '{file_key}' uploaded successfully!")

    # Generate a pre-signed URL for the uploaded file
    pre_signed_url = s3_client.generate_presigned_url(
        ClientMethod='get_object',
        Params={
            'Bucket': bucket_name,
            'Key': file_key
        },
        ExpiresIn=36000  # URL expiry time in seconds (1 hour)
    )

    print(f"Uploaded file URL: {pre_signed_url}")
    return pre_signed_url

# List objects in the bucket
# print("\nObjects in the bucket:")
# response = s3_client.list_objects_v2(Bucket=bucket_name)
# for obj in response.get('Contents', []):
#     print(obj['Key'])


def upload_audio_to_s3(file_obj: str, file_key: str) -> str:
    """
    Uploads an audio file to an S3 bucket and returns the Google Cloud Storage (GCS) path.
    
    Args:
        file_obj (str): The local path of the audio file to upload.
        bucket_name (str): The name of the S3 bucket.
        file_key (str): The object name in S3 (filename in the bucket).
        region (str): The AWS region where the bucket is hosted.

    Returns:
        str: The Google Cloud Storage (GCS) path to the uploaded audio file.
    """
    try:
        s3_client = boto3.client('s3')
        print("Uploading audio file...")
        s3_client.upload_file(
            Filename=file_obj,
            Bucket=bucket_name,
            Key=file_key,
            ExtraArgs={'ContentType': 'audio/mpeg'}
        )
        
        print(f"\nFile '{file_key}' uploaded successfully!")

        # Generate a pre-signed URL for accessing the uploaded file
        pre_signed_url = s3_client.generate_presigned_url(
            ClientMethod='get_object',
            Params={
                'Bucket': bucket_name,
                'Key': file_key
            },
            ExpiresIn=36000  # URL expiry time in seconds
        )

        # Convert the S3 URL to a Google Cloud Storage-like format
        audio_uri = f"gs://{bucket_name}/{file_key}"
        print(f"Uploaded file GCS path: {audio_uri}")
        
        return audio_uri
    
    except NoCredentialsError:
        print("AWS credentials not found.")
        return ""

